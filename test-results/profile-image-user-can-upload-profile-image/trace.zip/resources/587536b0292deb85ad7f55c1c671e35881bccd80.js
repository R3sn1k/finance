(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_dashboard_DashboardClient_tsx_3cac3f97._.js",
  "static/chunks/node_modules_93f6fee5._.js"
],
    source: "dynamic"
});
